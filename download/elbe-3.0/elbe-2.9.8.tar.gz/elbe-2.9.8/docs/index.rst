ELBE docs
==========

.. toctree::
   :maxdepth: 2
   :glob:
   :reversed:

   article*

.. toctree::
   :maxdepth: 1
   :glob:
   :caption: man-pages

   elbe*

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
